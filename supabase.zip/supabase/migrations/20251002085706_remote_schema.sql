revoke delete on table "public"."cart" from "anon";

revoke insert on table "public"."cart" from "anon";

revoke references on table "public"."cart" from "anon";

revoke select on table "public"."cart" from "anon";

revoke trigger on table "public"."cart" from "anon";

revoke truncate on table "public"."cart" from "anon";

revoke update on table "public"."cart" from "anon";

revoke delete on table "public"."cart" from "authenticated";

revoke insert on table "public"."cart" from "authenticated";

revoke references on table "public"."cart" from "authenticated";

revoke select on table "public"."cart" from "authenticated";

revoke trigger on table "public"."cart" from "authenticated";

revoke truncate on table "public"."cart" from "authenticated";

revoke update on table "public"."cart" from "authenticated";

revoke delete on table "public"."cart" from "service_role";

revoke insert on table "public"."cart" from "service_role";

revoke references on table "public"."cart" from "service_role";

revoke select on table "public"."cart" from "service_role";

revoke trigger on table "public"."cart" from "service_role";

revoke truncate on table "public"."cart" from "service_role";

revoke update on table "public"."cart" from "service_role";

revoke delete on table "public"."categories" from "anon";

revoke insert on table "public"."categories" from "anon";

revoke references on table "public"."categories" from "anon";

revoke select on table "public"."categories" from "anon";

revoke trigger on table "public"."categories" from "anon";

revoke truncate on table "public"."categories" from "anon";

revoke update on table "public"."categories" from "anon";

revoke delete on table "public"."categories" from "authenticated";

revoke insert on table "public"."categories" from "authenticated";

revoke references on table "public"."categories" from "authenticated";

revoke select on table "public"."categories" from "authenticated";

revoke trigger on table "public"."categories" from "authenticated";

revoke truncate on table "public"."categories" from "authenticated";

revoke update on table "public"."categories" from "authenticated";

revoke delete on table "public"."categories" from "service_role";

revoke insert on table "public"."categories" from "service_role";

revoke references on table "public"."categories" from "service_role";

revoke select on table "public"."categories" from "service_role";

revoke trigger on table "public"."categories" from "service_role";

revoke truncate on table "public"."categories" from "service_role";

revoke update on table "public"."categories" from "service_role";

revoke delete on table "public"."kv_store_6985f4e9" from "anon";

revoke insert on table "public"."kv_store_6985f4e9" from "anon";

revoke references on table "public"."kv_store_6985f4e9" from "anon";

revoke select on table "public"."kv_store_6985f4e9" from "anon";

revoke trigger on table "public"."kv_store_6985f4e9" from "anon";

revoke truncate on table "public"."kv_store_6985f4e9" from "anon";

revoke update on table "public"."kv_store_6985f4e9" from "anon";

revoke delete on table "public"."kv_store_6985f4e9" from "authenticated";

revoke insert on table "public"."kv_store_6985f4e9" from "authenticated";

revoke references on table "public"."kv_store_6985f4e9" from "authenticated";

revoke select on table "public"."kv_store_6985f4e9" from "authenticated";

revoke trigger on table "public"."kv_store_6985f4e9" from "authenticated";

revoke truncate on table "public"."kv_store_6985f4e9" from "authenticated";

revoke update on table "public"."kv_store_6985f4e9" from "authenticated";

revoke delete on table "public"."kv_store_6985f4e9" from "service_role";

revoke insert on table "public"."kv_store_6985f4e9" from "service_role";

revoke references on table "public"."kv_store_6985f4e9" from "service_role";

revoke select on table "public"."kv_store_6985f4e9" from "service_role";

revoke trigger on table "public"."kv_store_6985f4e9" from "service_role";

revoke truncate on table "public"."kv_store_6985f4e9" from "service_role";

revoke update on table "public"."kv_store_6985f4e9" from "service_role";

revoke delete on table "public"."order_items" from "anon";

revoke insert on table "public"."order_items" from "anon";

revoke references on table "public"."order_items" from "anon";

revoke select on table "public"."order_items" from "anon";

revoke trigger on table "public"."order_items" from "anon";

revoke truncate on table "public"."order_items" from "anon";

revoke update on table "public"."order_items" from "anon";

revoke delete on table "public"."order_items" from "authenticated";

revoke insert on table "public"."order_items" from "authenticated";

revoke references on table "public"."order_items" from "authenticated";

revoke select on table "public"."order_items" from "authenticated";

revoke trigger on table "public"."order_items" from "authenticated";

revoke truncate on table "public"."order_items" from "authenticated";

revoke update on table "public"."order_items" from "authenticated";

revoke delete on table "public"."order_items" from "service_role";

revoke insert on table "public"."order_items" from "service_role";

revoke references on table "public"."order_items" from "service_role";

revoke select on table "public"."order_items" from "service_role";

revoke trigger on table "public"."order_items" from "service_role";

revoke truncate on table "public"."order_items" from "service_role";

revoke update on table "public"."order_items" from "service_role";

revoke delete on table "public"."orders" from "anon";

revoke insert on table "public"."orders" from "anon";

revoke references on table "public"."orders" from "anon";

revoke select on table "public"."orders" from "anon";

revoke trigger on table "public"."orders" from "anon";

revoke truncate on table "public"."orders" from "anon";

revoke update on table "public"."orders" from "anon";

revoke delete on table "public"."orders" from "authenticated";

revoke insert on table "public"."orders" from "authenticated";

revoke references on table "public"."orders" from "authenticated";

revoke select on table "public"."orders" from "authenticated";

revoke trigger on table "public"."orders" from "authenticated";

revoke truncate on table "public"."orders" from "authenticated";

revoke update on table "public"."orders" from "authenticated";

revoke delete on table "public"."orders" from "service_role";

revoke insert on table "public"."orders" from "service_role";

revoke references on table "public"."orders" from "service_role";

revoke select on table "public"."orders" from "service_role";

revoke trigger on table "public"."orders" from "service_role";

revoke truncate on table "public"."orders" from "service_role";

revoke update on table "public"."orders" from "service_role";

revoke delete on table "public"."otp_verification" from "anon";

revoke insert on table "public"."otp_verification" from "anon";

revoke references on table "public"."otp_verification" from "anon";

revoke select on table "public"."otp_verification" from "anon";

revoke trigger on table "public"."otp_verification" from "anon";

revoke truncate on table "public"."otp_verification" from "anon";

revoke update on table "public"."otp_verification" from "anon";

revoke delete on table "public"."otp_verification" from "authenticated";

revoke insert on table "public"."otp_verification" from "authenticated";

revoke references on table "public"."otp_verification" from "authenticated";

revoke select on table "public"."otp_verification" from "authenticated";

revoke trigger on table "public"."otp_verification" from "authenticated";

revoke truncate on table "public"."otp_verification" from "authenticated";

revoke update on table "public"."otp_verification" from "authenticated";

revoke delete on table "public"."otp_verification" from "service_role";

revoke insert on table "public"."otp_verification" from "service_role";

revoke references on table "public"."otp_verification" from "service_role";

revoke select on table "public"."otp_verification" from "service_role";

revoke trigger on table "public"."otp_verification" from "service_role";

revoke truncate on table "public"."otp_verification" from "service_role";

revoke update on table "public"."otp_verification" from "service_role";

revoke delete on table "public"."product_subscriptions" from "anon";

revoke insert on table "public"."product_subscriptions" from "anon";

revoke references on table "public"."product_subscriptions" from "anon";

revoke select on table "public"."product_subscriptions" from "anon";

revoke trigger on table "public"."product_subscriptions" from "anon";

revoke truncate on table "public"."product_subscriptions" from "anon";

revoke update on table "public"."product_subscriptions" from "anon";

revoke delete on table "public"."product_subscriptions" from "authenticated";

revoke insert on table "public"."product_subscriptions" from "authenticated";

revoke references on table "public"."product_subscriptions" from "authenticated";

revoke select on table "public"."product_subscriptions" from "authenticated";

revoke trigger on table "public"."product_subscriptions" from "authenticated";

revoke truncate on table "public"."product_subscriptions" from "authenticated";

revoke update on table "public"."product_subscriptions" from "authenticated";

revoke delete on table "public"."product_subscriptions" from "service_role";

revoke insert on table "public"."product_subscriptions" from "service_role";

revoke references on table "public"."product_subscriptions" from "service_role";

revoke select on table "public"."product_subscriptions" from "service_role";

revoke trigger on table "public"."product_subscriptions" from "service_role";

revoke truncate on table "public"."product_subscriptions" from "service_role";

revoke update on table "public"."product_subscriptions" from "service_role";

revoke delete on table "public"."products" from "anon";

revoke insert on table "public"."products" from "anon";

revoke references on table "public"."products" from "anon";

revoke select on table "public"."products" from "anon";

revoke trigger on table "public"."products" from "anon";

revoke truncate on table "public"."products" from "anon";

revoke update on table "public"."products" from "anon";

revoke delete on table "public"."products" from "authenticated";

revoke insert on table "public"."products" from "authenticated";

revoke references on table "public"."products" from "authenticated";

revoke select on table "public"."products" from "authenticated";

revoke trigger on table "public"."products" from "authenticated";

revoke truncate on table "public"."products" from "authenticated";

revoke update on table "public"."products" from "authenticated";

revoke delete on table "public"."products" from "service_role";

revoke insert on table "public"."products" from "service_role";

revoke references on table "public"."products" from "service_role";

revoke select on table "public"."products" from "service_role";

revoke trigger on table "public"."products" from "service_role";

revoke truncate on table "public"."products" from "service_role";

revoke update on table "public"."products" from "service_role";

revoke delete on table "public"."subscription_deliveries" from "anon";

revoke insert on table "public"."subscription_deliveries" from "anon";

revoke references on table "public"."subscription_deliveries" from "anon";

revoke select on table "public"."subscription_deliveries" from "anon";

revoke trigger on table "public"."subscription_deliveries" from "anon";

revoke truncate on table "public"."subscription_deliveries" from "anon";

revoke update on table "public"."subscription_deliveries" from "anon";

revoke delete on table "public"."subscription_deliveries" from "authenticated";

revoke insert on table "public"."subscription_deliveries" from "authenticated";

revoke references on table "public"."subscription_deliveries" from "authenticated";

revoke select on table "public"."subscription_deliveries" from "authenticated";

revoke trigger on table "public"."subscription_deliveries" from "authenticated";

revoke truncate on table "public"."subscription_deliveries" from "authenticated";

revoke update on table "public"."subscription_deliveries" from "authenticated";

revoke delete on table "public"."subscription_deliveries" from "service_role";

revoke insert on table "public"."subscription_deliveries" from "service_role";

revoke references on table "public"."subscription_deliveries" from "service_role";

revoke select on table "public"."subscription_deliveries" from "service_role";

revoke trigger on table "public"."subscription_deliveries" from "service_role";

revoke truncate on table "public"."subscription_deliveries" from "service_role";

revoke update on table "public"."subscription_deliveries" from "service_role";

revoke delete on table "public"."subscription_items" from "anon";

revoke insert on table "public"."subscription_items" from "anon";

revoke references on table "public"."subscription_items" from "anon";

revoke select on table "public"."subscription_items" from "anon";

revoke trigger on table "public"."subscription_items" from "anon";

revoke truncate on table "public"."subscription_items" from "anon";

revoke update on table "public"."subscription_items" from "anon";

revoke delete on table "public"."subscription_items" from "authenticated";

revoke insert on table "public"."subscription_items" from "authenticated";

revoke references on table "public"."subscription_items" from "authenticated";

revoke select on table "public"."subscription_items" from "authenticated";

revoke trigger on table "public"."subscription_items" from "authenticated";

revoke truncate on table "public"."subscription_items" from "authenticated";

revoke update on table "public"."subscription_items" from "authenticated";

revoke delete on table "public"."subscription_items" from "service_role";

revoke insert on table "public"."subscription_items" from "service_role";

revoke references on table "public"."subscription_items" from "service_role";

revoke select on table "public"."subscription_items" from "service_role";

revoke trigger on table "public"."subscription_items" from "service_role";

revoke truncate on table "public"."subscription_items" from "service_role";

revoke update on table "public"."subscription_items" from "service_role";

revoke delete on table "public"."user_addresses" from "anon";

revoke insert on table "public"."user_addresses" from "anon";

revoke references on table "public"."user_addresses" from "anon";

revoke select on table "public"."user_addresses" from "anon";

revoke trigger on table "public"."user_addresses" from "anon";

revoke truncate on table "public"."user_addresses" from "anon";

revoke update on table "public"."user_addresses" from "anon";

revoke delete on table "public"."user_addresses" from "authenticated";

revoke insert on table "public"."user_addresses" from "authenticated";

revoke references on table "public"."user_addresses" from "authenticated";

revoke select on table "public"."user_addresses" from "authenticated";

revoke trigger on table "public"."user_addresses" from "authenticated";

revoke truncate on table "public"."user_addresses" from "authenticated";

revoke update on table "public"."user_addresses" from "authenticated";

revoke delete on table "public"."user_addresses" from "service_role";

revoke insert on table "public"."user_addresses" from "service_role";

revoke references on table "public"."user_addresses" from "service_role";

revoke select on table "public"."user_addresses" from "service_role";

revoke trigger on table "public"."user_addresses" from "service_role";

revoke truncate on table "public"."user_addresses" from "service_role";

revoke update on table "public"."user_addresses" from "service_role";

revoke delete on table "public"."users" from "anon";

revoke insert on table "public"."users" from "anon";

revoke references on table "public"."users" from "anon";

revoke select on table "public"."users" from "anon";

revoke trigger on table "public"."users" from "anon";

revoke truncate on table "public"."users" from "anon";

revoke update on table "public"."users" from "anon";

revoke delete on table "public"."users" from "authenticated";

revoke insert on table "public"."users" from "authenticated";

revoke references on table "public"."users" from "authenticated";

revoke select on table "public"."users" from "authenticated";

revoke trigger on table "public"."users" from "authenticated";

revoke truncate on table "public"."users" from "authenticated";

revoke update on table "public"."users" from "authenticated";

revoke delete on table "public"."users" from "service_role";

revoke insert on table "public"."users" from "service_role";

revoke references on table "public"."users" from "service_role";

revoke select on table "public"."users" from "service_role";

revoke trigger on table "public"."users" from "service_role";

revoke truncate on table "public"."users" from "service_role";

revoke update on table "public"."users" from "service_role";

revoke delete on table "public"."vendors" from "anon";

revoke insert on table "public"."vendors" from "anon";

revoke references on table "public"."vendors" from "anon";

revoke select on table "public"."vendors" from "anon";

revoke trigger on table "public"."vendors" from "anon";

revoke truncate on table "public"."vendors" from "anon";

revoke update on table "public"."vendors" from "anon";

revoke delete on table "public"."vendors" from "authenticated";

revoke insert on table "public"."vendors" from "authenticated";

revoke references on table "public"."vendors" from "authenticated";

revoke select on table "public"."vendors" from "authenticated";

revoke trigger on table "public"."vendors" from "authenticated";

revoke truncate on table "public"."vendors" from "authenticated";

revoke update on table "public"."vendors" from "authenticated";

revoke delete on table "public"."vendors" from "service_role";

revoke insert on table "public"."vendors" from "service_role";

revoke references on table "public"."vendors" from "service_role";

revoke select on table "public"."vendors" from "service_role";

revoke trigger on table "public"."vendors" from "service_role";

revoke truncate on table "public"."vendors" from "service_role";

revoke update on table "public"."vendors" from "service_role";

alter table "public"."user_addresses" alter column "id" set default extensions.uuid_generate_v4();

set check_function_bodies = off;

CREATE OR REPLACE FUNCTION public.ensure_single_default_address()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- If setting this address as default, unset all other defaults for this user
    IF NEW.is_default = true THEN
        UPDATE user_addresses 
        SET is_default = false 
        WHERE user_id = NEW.user_id AND id != NEW.id;
    END IF;
    
    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.get_user_default_address(input_user_id uuid)
 RETURNS TABLE(id uuid, type character varying, custom_tag character varying, house_number character varying, apartment_road character varying, complete_address text, latitude numeric, longitude numeric, phone character varying, display_type text, short_address text)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
    RETURN QUERY
    SELECT 
        ua.id,
        ua.type,
        ua.custom_tag,
        ua.house_number,
        ua.apartment_road,
        ua.complete_address,
        ua.latitude,
        ua.longitude,
        ua.phone,
        uad.display_type,
        uad.short_address
    FROM public.user_addresses ua
    JOIN public.user_addresses_display uad ON ua.id = uad.id
    WHERE ua.user_id = input_user_id 
    AND ua.is_default = TRUE
    LIMIT 1;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.update_cart_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.update_user_addresses_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    NEW.updated_at = TIMEZONE('utc', NOW());
    RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.upsert_otp_verification(p_phone text, p_otp text, p_expires_at timestamp with time zone)
 RETURNS uuid
 LANGUAGE plpgsql
AS $function$
DECLARE
  result_id UUID;
BEGIN
  -- Try to update existing record first
  UPDATE otp_verification 
  SET 
    otp = p_otp,
    expires_at = p_expires_at,
    verified = FALSE,
    attempts = 0,
    created_at = NOW(),
    verified_at = NULL
  WHERE phone = p_phone
  RETURNING id INTO result_id;
  
  -- If no record was updated, insert a new one
  IF NOT FOUND THEN
    INSERT INTO otp_verification (phone, otp, expires_at, verified, attempts, created_at)
    VALUES (p_phone, p_otp, p_expires_at, FALSE, 0, NOW())
    RETURNING id INTO result_id;
  END IF;
  
  RETURN result_id;
END;
$function$
;



